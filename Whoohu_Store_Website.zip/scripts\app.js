/**
 * Whoohu Store - Application Logic
 * Interactive Cart, Wishlist, Search, Filter, Modals, Checkout & Qatar Localization
 */

// Application State
const AppState = {
  cart: [],
  wishlist: [],
  activeCategory: 'all',
  activeSort: 'featured',
  searchQuery: '',
  appliedPromo: null,
  promos: {
    'QATAR10': { type: 'percent', value: 10, label: '10% Off Qatar Welcome' },
    'WHOOHU20': { type: 'fixed', value: 20, label: '20 QAR Off' },
    'FREESHIP': { type: 'shipping', value: 0, label: 'Free Qatar Express Delivery' }
  },
  selectedProductForModal: null,
  shippingThreshold: 250, // Free delivery in Qatar for orders over 250 QAR
  standardShippingRate: 25
};

// Initialize App
document.addEventListener('DOMContentLoaded', () => {
  loadSavedState();
  initHeader();
  initSearch();
  initHeroCollage();
  renderCategoryCards();
  initCatalog();
  initCountdown();
  initCartDrawer();
  initQuickViewModal();
  initCheckoutModal();
  initNewsletter();
  initThemeCustomizer();
  updateCartBadge();
  updateWishlistBadge();

  // Graceful fallback for any image load issues
  document.addEventListener('error', (e) => {
    if (e.target && e.target.tagName === 'IMG' && !e.target.dataset.fallbackApplied) {
      e.target.dataset.fallbackApplied = 'true';
      const alt = encodeURIComponent(e.target.alt || 'WHOohu Qatar');
      e.target.src = `data:image/svg+xml;utf8,<svg xmlns="http://www.w3.org/2000/svg" width="600" height="700" viewBox="0 0 600 700"><rect width="100%" height="100%" fill="%23EDE7DC"/><circle cx="300" cy="310" r="48" fill="%23F8F5EE"/><text x="300" y="322" font-family="serif" font-size="36" font-weight="bold" fill="%23183C2B" text-anchor="middle">W</text><text x="300" y="380" font-family="sans-serif" font-size="16" font-weight="600" fill="%23183C2B" text-anchor="middle">${alt}</text><text x="300" y="410" font-family="sans-serif" font-size="13" fill="%23D98A72" text-anchor="middle">Whoohu Store Qatar</text></svg>`;
    }
  }, true);
});

// Load state from localStorage
function loadSavedState() {
  try {
    const savedCart = localStorage.getItem('whoohu_cart');
    if (savedCart) AppState.cart = JSON.parse(savedCart);

    const savedWishlist = localStorage.getItem('whoohu_wishlist');
    if (savedWishlist) AppState.wishlist = JSON.parse(savedWishlist);
  } catch (e) {
    console.error('Error loading saved state', e);
  }
}

function saveState() {
  try {
    localStorage.setItem('whoohu_cart', JSON.stringify(AppState.cart));
    localStorage.setItem('whoohu_wishlist', JSON.stringify(AppState.wishlist));
  } catch (e) {
    console.error('Error saving state', e);
  }
}

/* ==========================================================================
   1. HEADER & NAVIGATION
   ========================================================================== */
function initHeader() {
  const headerWrapper = document.querySelector('.header-wrapper');
  
  window.addEventListener('scroll', () => {
    if (window.scrollY > 40) {
      headerWrapper.classList.add('header-scrolled');
    } else {
      headerWrapper.classList.remove('header-scrolled');
    }
  });

  // Mobile menu drawer
  const mobileToggle = document.getElementById('mobileMenuToggle');
  const mobileDrawer = document.getElementById('mobileNavDrawer');
  const mobileClose = document.getElementById('mobileNavClose');
  const backdrop = document.getElementById('drawerBackdrop');

  if (mobileToggle && mobileDrawer && backdrop) {
    mobileToggle.addEventListener('click', () => {
      mobileDrawer.classList.add('active');
      backdrop.classList.add('active');
      document.body.style.overflow = 'hidden';
    });

    const closeMobileMenu = () => {
      mobileDrawer.classList.remove('active');
      if (!document.getElementById('cartDrawer').classList.contains('active')) {
        backdrop.classList.remove('active');
        document.body.style.overflow = '';
      }
    };

    if (mobileClose) mobileClose.addEventListener('click', closeMobileMenu);
    
    // Close on link click
    document.querySelectorAll('.mobile-nav-link').forEach(link => {
      link.addEventListener('click', (e) => {
        closeMobileMenu();
        const cat = link.getAttribute('data-category');
        if (cat) filterByTab(cat);
      });
    });
  }

  // Desktop navigation click handling
  document.querySelectorAll('.nav-link').forEach(link => {
    link.addEventListener('click', (e) => {
      const cat = link.getAttribute('data-category');
      if (cat) {
        e.preventDefault();
        filterByTab(cat);
        // Smooth scroll to catalog
        const catSection = document.getElementById('catalog');
        if (catSection) {
          catSection.scrollIntoView({ behavior: 'smooth' });
        }
      }
    });
  });
}

/* ==========================================================================
   2. LIVE SEARCH ENGINE & AUTOCOMPLETE
   ========================================================================== */
function initSearch() {
  const searchInput = document.getElementById('mainSearchInput');
  const searchResults = document.getElementById('searchResultsDropdown');
  const searchClear = document.getElementById('searchClearBtn');

  if (!searchInput || !searchResults) return;

  searchInput.addEventListener('input', (e) => {
    const query = e.target.value.trim().toLowerCase();
    AppState.searchQuery = query;

    if (query.length > 0) {
      searchClear.style.display = 'block';
      const matches = WHOOHU_PRODUCTS.filter(p => 
        p.name.toLowerCase().includes(query) ||
        p.categoryName.toLowerCase().includes(query) ||
        p.description.toLowerCase().includes(query)
      ).slice(0, 6);

      renderSearchResults(matches, searchResults);
      searchResults.classList.add('active');
    } else {
      searchClear.style.display = 'none';
      searchResults.classList.remove('active');
    }
  });

  searchClear.addEventListener('click', () => {
    searchInput.value = '';
    AppState.searchQuery = '';
    searchClear.style.display = 'none';
    searchResults.classList.remove('active');
    renderProducts();
  });

  // Close dropdown on outside click
  document.addEventListener('click', (e) => {
    if (!searchInput.contains(e.target) && !searchResults.contains(e.target)) {
      searchResults.classList.remove('active');
    }
  });

  // Submit search
  const searchForm = document.getElementById('mainSearchForm');
  if (searchForm) {
    searchForm.addEventListener('submit', (e) => {
      e.preventDefault();
      searchResults.classList.remove('active');
      renderProducts();
      document.getElementById('catalog').scrollIntoView({ behavior: 'smooth' });
    });
  }
}

function renderSearchResults(matches, container) {
  if (matches.length === 0) {
    container.innerHTML = `
      <div style="padding: 20px; text-align: center; color: var(--c-charcoal-muted); font-size: 0.9rem;">
        No products found in Qatar catalog matching your search.
      </div>
    `;
    return;
  }

  let html = `<div class="search-dropdown-header">Matching Products in Qatar (${matches.length})</div>`;
  matches.forEach(product => {
    html += `
      <div class="search-item" onclick="openProductQuickView('${product.id}')">
        <img class="search-item-img" src="${product.image}" alt="${product.name}" />
        <div class="search-item-info">
          <div class="search-item-title">${product.name}</div>
          <div class="search-item-meta">
            <span>${product.categoryName}</span> •
            <span class="search-item-price">${product.price} QAR</span>
          </div>
        </div>
      </div>
    `;
  });
  container.innerHTML = html;
}

/* ==========================================================================
   3. HERO COLLAGE INTERACTION
   ========================================================================== */
function initHeroCollage() {
  const collage = document.getElementById('heroCollage');
  if (!collage) return;

  // Add subtle parallax on mousemove for desktop
  collage.addEventListener('mousemove', (e) => {
    if (window.innerWidth < 992) return;
    const rect = collage.getBoundingClientRect();
    const x = (e.clientX - rect.left) / rect.width - 0.5;
    const y = (e.clientY - rect.top) / rect.height - 0.5;

    const cards = collage.querySelectorAll('.collage-float');
    cards.forEach((card, idx) => {
      const depth = (idx + 1) * 12;
      card.style.transform = `translate(${x * depth}px, ${y * depth}px)`;
    });
  });

  collage.addEventListener('mouseleave', () => {
    const cards = collage.querySelectorAll('.collage-float');
    cards.forEach(card => {
      card.style.transform = '';
    });
  });
}

/* ==========================================================================
   4. CATEGORY CARDS
   ========================================================================== */
function renderCategoryCards() {
  const categories = [
    {
      id: "fashion",
      title: "Fashion",
      class: "cat-fashion",
      desc: "Effortless silhouettes, luxury silks, contemporary modest abayas, tailored linens & fine leather.",
      count: "48 Products",
      image: "https://images.unsplash.com/photo-1490481651871-ab68de25d43d?auto=format&fit=crop&w=1200&q=80"
    },
    {
      id: "beauty",
      title: "Beauty",
      class: "cat-beauty",
      desc: "Luminous saffron skincare, rare Taif rose ouds, pure botanical elixirs & sculpting tools.",
      count: "32 Products",
      image: "https://images.unsplash.com/photo-1596462502278-27bfdc403348?auto=format&fit=crop&w=800&q=80"
    },
    {
      id: "gadgets",
      title: "Gadgets",
      class: "cat-gadgets",
      desc: "Sleek studio acoustic gear, solid walnut MagSafe charging hubs & Nordic ambient lighting.",
      count: "24 Products",
      image: "https://images.unsplash.com/photo-1550009158-9ebf69173e03?auto=format&fit=crop&w=800&q=80"
    },
    {
      id: "home",
      title: "Home & Kitchen",
      class: "cat-home",
      desc: "Artisanal Portuguese ceramics, hand-hammered brass coffee sets & pure French flax bedding.",
      count: "36 Products",
      image: "https://images.unsplash.com/photo-1513694203232-719a280e022f?auto=format&fit=crop&w=800&q=80"
    },
    {
      id: "gifts",
      title: "Gifts",
      class: "cat-gifts",
      desc: "Royal Doha heritage velvet hampers, personalized monogram leather & curated sweet surprises.",
      count: "29 Products",
      image: "https://images.unsplash.com/photo-1513885535751-8b9238bd345a?auto=format&fit=crop&w=800&q=80"
    }
  ];

  const grid = document.getElementById('categoriesGrid');
  if (!grid) return;

  grid.innerHTML = categories.map(cat => `
    <div class="category-card ${cat.class}" onclick="filterByTab('${cat.id}'); document.getElementById('catalog').scrollIntoView({ behavior: 'smooth' });">
      <img class="category-card-bg" src="${cat.image}" alt="${cat.title}" loading="lazy" />
      <div class="category-card-overlay"></div>
      <div class="category-card-content">
        <span class="category-card-count">${cat.count}</span>
        <h3 class="category-card-title">${cat.title}</h3>
        <p class="category-card-desc">${cat.desc}</p>
        <span class="category-card-action">Explore Collection →</span>
      </div>
    </div>
  `).join('');
}

/* ==========================================================================
   5. PRODUCT CATALOG, FILTERING & SORTING
   ========================================================================== */
function initCatalog() {
  // Filter tab buttons
  document.querySelectorAll('.filter-tab').forEach(btn => {
    btn.addEventListener('click', () => {
      const cat = btn.getAttribute('data-filter');
      filterByTab(cat);
    });
  });

  // Sort dropdown
  const sortSelect = document.getElementById('catalogSortSelect');
  if (sortSelect) {
    sortSelect.addEventListener('change', (e) => {
      AppState.activeSort = e.target.value;
      renderProducts();
    });
  }

  renderProducts();
}

function filterByTab(category) {
  AppState.activeCategory = category;

  // Update tabs UI
  document.querySelectorAll('.filter-tab').forEach(tab => {
    if (tab.getAttribute('data-filter') === category) {
      tab.classList.add('active');
    } else {
      tab.classList.remove('active');
    }
  });

  // Update nav links UI
  document.querySelectorAll('.nav-link').forEach(link => {
    if (link.getAttribute('data-category') === category) {
      link.classList.add('active');
    } else {
      link.classList.remove('active');
    }
  });

  renderProducts();
}

function renderProducts() {
  const grid = document.getElementById('productsGrid');
  if (!grid) return;

  let products = [...WHOOHU_PRODUCTS];

  // 1. Filter by category or special flag
  if (AppState.activeCategory === 'trending') {
    products = products.filter(p => p.trending);
  } else if (AppState.activeCategory === 'new') {
    products = products.filter(p => p.newArrival);
  } else if (AppState.activeCategory !== 'all') {
    products = products.filter(p => p.category.toLowerCase() === AppState.activeCategory.toLowerCase());
  }

  // 2. Filter by search query
  if (AppState.searchQuery) {
    products = products.filter(p => 
      p.name.toLowerCase().includes(AppState.searchQuery) ||
      p.categoryName.toLowerCase().includes(AppState.searchQuery) ||
      p.description.toLowerCase().includes(AppState.searchQuery)
    );
  }

  // 3. Sort
  if (AppState.activeSort === 'price-low') {
    products.sort((a, b) => a.price - b.price);
  } else if (AppState.activeSort === 'price-high') {
    products.sort((a, b) => b.price - a.price);
  } else if (AppState.activeSort === 'rating') {
    products.sort((a, b) => b.rating - a.rating);
  } else {
    // featured: prioritized
    products.sort((a, b) => (b.featured ? 1 : 0) - (a.featured ? 1 : 0));
  }

  if (products.length === 0) {
    grid.innerHTML = `
      <div style="grid-column: 1 / -1; text-align: center; padding: 60px 20px;">
        <h3 style="font-size: 1.5rem; color: var(--c-forest); margin-bottom: 8px;">No products found</h3>
        <p style="color: var(--c-charcoal-muted); margin-bottom: 20px;">Try switching categories or clearing search keywords.</p>
        <button class="btn btn-secondary btn-sm" onclick="filterByTab('all')">View All Products</button>
      </div>
    `;
    return;
  }

  grid.innerHTML = products.map(product => {
    const isWishlisted = AppState.wishlist.includes(product.id);
    const badgeHtml = product.badge ? `
      <span class="product-badge-tag ${product.badge === 'NEW IN' ? 'tag-new' : product.badge === 'QATAR EXCLUSIVE' ? 'tag-exclusive' : ''}">
        ${product.badge}
      </span>
    ` : '';

    return `
      <div class="product-card" data-id="${product.id}">
        <div class="product-image-box">
          ${badgeHtml}
          <button class="product-wishlist-btn ${isWishlisted ? 'active' : ''}" onclick="toggleWishlist('${product.id}', this)" title="Add to Wishlist" aria-label="Add to Wishlist">
            <svg width="18" height="18" viewBox="0 0 24 24" fill="${isWishlisted ? 'currentColor' : 'none'}" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
              <path d="M19 14c1.49-1.46 3-3.21 3-5.5A5.5 5.5 0 0 0 16.5 3c-1.76 0-3 .5-4.5 2-1.5-1.5-2.74-2-4.5-2A5.5 5.5 0 0 0 2 8.5c0 2.3 1.5 4.05 3 5.5l7 7Z"/>
            </svg>
          </button>
          
          <img class="product-img" src="${product.image}" alt="${product.name}" loading="lazy" />
          <img class="product-img-hover" src="${product.hoverImage}" alt="${product.name}" loading="lazy" />

          <button class="product-quickview-btn" onclick="openProductQuickView('${product.id}')">
            <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M2 12s3-7 10-7 10 7 10 7-3 7-10 7-10-7-10-7Z"/><circle cx="12" cy="12" r="3"/></svg>
            Quick View
          </button>
        </div>

        <div class="product-details">
          <span class="product-category-meta">${product.categoryName}</span>
          <h4 class="product-title">
            <a href="javascript:void(0)" onclick="openProductQuickView('${product.id}')">${product.name}</a>
          </h4>

          <div class="product-rating">
            <div class="stars">
              ${'★'.repeat(Math.floor(product.rating))}
            </div>
            <span>${product.rating.toFixed(1)} (${product.reviewsCount})</span>
          </div>

          <div class="product-price-row">
            <div class="product-prices">
              <span class="price-current">${product.price} QAR</span>
              ${product.originalPrice ? `<span class="price-original">${product.originalPrice} QAR</span>` : ''}
            </div>

            <button class="product-add-cart-btn" onclick="quickAddToCart('${product.id}', this)" title="Add to Cart" aria-label="Add to Cart">
              <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
                <path d="M5 12h14"/><path d="M12 5v14"/>
              </svg>
            </button>
          </div>
        </div>
      </div>
    `;
  }).join('');
}

/* ==========================================================================
   6. CART SYSTEM & SLIDE-OUT DRAWER
   ========================================================================== */
function initCartDrawer() {
  const cartTrigger = document.getElementById('cartTrigger');
  const cartDrawer = document.getElementById('cartDrawer');
  const cartClose = document.getElementById('cartCloseBtn');
  const backdrop = document.getElementById('drawerBackdrop');
  const promoBtn = document.getElementById('applyPromoBtn');

  if (cartTrigger && cartDrawer && backdrop) {
    cartTrigger.addEventListener('click', () => {
      openCartDrawer();
    });

    const closeCart = () => {
      cartDrawer.classList.remove('active');
      backdrop.classList.remove('active');
      document.body.style.overflow = '';
    };

    if (cartClose) cartClose.addEventListener('click', closeCart);
    backdrop.addEventListener('click', () => {
      closeCart();
      const mobileDrawer = document.getElementById('mobileNavDrawer');
      if (mobileDrawer) mobileDrawer.classList.remove('active');
      closeQuickView();
      closeCheckout();
    });
  }

  // Promo code handler
  if (promoBtn) {
    promoBtn.addEventListener('click', () => {
      const promoInput = document.getElementById('promoCodeInput');
      const code = promoInput.value.trim().toUpperCase();
      applyCoupon(code);
    });
  }
}

function openCartDrawer() {
  const cartDrawer = document.getElementById('cartDrawer');
  const backdrop = document.getElementById('drawerBackdrop');
  if (cartDrawer && backdrop) {
    renderCart();
    cartDrawer.classList.add('active');
    backdrop.classList.add('active');
    document.body.style.overflow = 'hidden';
  }
}

function quickAddToCart(productId, buttonElem) {
  addToCart(productId, 1);
  if (buttonElem) {
    buttonElem.classList.add('added');
    buttonElem.innerHTML = `
      <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5" stroke-linecap="round" stroke-linejoin="round">
        <path d="M20 6 9 17l-5-5"/>
      </svg>
    `;
    setTimeout(() => {
      buttonElem.classList.remove('added');
      buttonElem.innerHTML = `
        <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
          <path d="M5 12h14"/><path d="M12 5v14"/>
        </svg>
      `;
    }, 1400);
  }
}

function addToCart(productId, quantity = 1, selectedVariant = null) {
  const product = getProductById(productId);
  if (!product) return;

  const defaultColor = product.variants?.colors ? product.variants.colors[0] : null;
  const defaultSize = product.variants?.sizes ? product.variants.sizes[0] : null;
  
  const variant = selectedVariant || {
    color: defaultColor,
    size: defaultSize
  };

  const existingIndex = AppState.cart.findIndex(item => 
    item.id === productId && 
    item.variant?.color === variant.color && 
    item.variant?.size === variant.size
  );

  if (existingIndex > -1) {
    AppState.cart[existingIndex].quantity += quantity;
  } else {
    AppState.cart.push({
      id: productId,
      name: product.name,
      price: product.price,
      image: product.image,
      variant: variant,
      quantity: quantity
    });
  }

  saveState();
  updateCartBadge();
  showToast(`Added "${product.name}" to your bag`, '🛍️');
}

function updateQuantity(index, delta) {
  if (!AppState.cart[index]) return;
  AppState.cart[index].quantity += delta;
  if (AppState.cart[index].quantity <= 0) {
    AppState.cart.splice(index, 1);
  }
  saveState();
  updateCartBadge();
  renderCart();
}

function removeCartItem(index) {
  AppState.cart.splice(index, 1);
  saveState();
  updateCartBadge();
  renderCart();
  showToast('Item removed from your bag', '🗑️');
}

function updateCartBadge() {
  const count = AppState.cart.reduce((sum, item) => sum + item.quantity, 0);
  const badge = document.getElementById('cartCounterBadge');
  if (badge) {
    badge.textContent = count;
    badge.style.display = count > 0 ? 'flex' : 'none';
  }
}

function renderCart() {
  const itemsContainer = document.getElementById('cartDrawerItems');
  const footerContainer = document.getElementById('cartDrawerFooter');
  const shippingText = document.getElementById('shippingProgressText');
  const shippingBar = document.getElementById('shippingProgressBar');

  if (!itemsContainer) return;

  if (AppState.cart.length === 0) {
    itemsContainer.innerHTML = `
      <div class="empty-cart-state">
        <div class="empty-cart-icon">🛍️</div>
        <h4 class="empty-cart-title">Your shopping bag is empty</h4>
        <p class="empty-cart-text">Explore our Qatar collections in fashion, beauty, gadgets, and luxury gifts.</p>
        <button class="btn btn-primary btn-sm" onclick="document.getElementById('cartDrawer').classList.remove('active'); document.getElementById('drawerBackdrop').classList.remove('active'); document.body.style.overflow = '';">
          Start Shopping
        </button>
      </div>
    `;
    if (footerContainer) footerContainer.style.display = 'none';
    if (shippingText && shippingBar) {
      shippingText.textContent = `Add 250 QAR for FREE Qatar Delivery`;
      shippingBar.style.width = '0%';
    }
    return;
  }

  if (footerContainer) footerContainer.style.display = 'block';

  // Subtotal calculation
  const subtotal = AppState.cart.reduce((sum, item) => sum + (item.price * item.quantity), 0);
  
  // Shipping progress calculation
  const remainingForFree = Math.max(0, AppState.shippingThreshold - subtotal);
  const progressPercent = Math.min(100, Math.round((subtotal / AppState.shippingThreshold) * 100));

  if (shippingText && shippingBar) {
    if (remainingForFree === 0) {
      shippingText.innerHTML = `<span>🎉 <strong>Congratulations!</strong></span> <span>You unlocked <strong>FREE Qatar Delivery</strong></span>`;
      shippingBar.style.width = '100%';
    } else {
      shippingText.innerHTML = `<span>Add <strong>${remainingForFree} QAR</strong> more for <strong>FREE Qatar Delivery</strong></span> <span>${progressPercent}%</span>`;
      shippingBar.style.width = `${progressPercent}%`;
    }
  }

  // Render items
  itemsContainer.innerHTML = AppState.cart.map((item, idx) => `
    <div class="cart-item">
      <img class="cart-item-img" src="${item.image}" alt="${item.name}" />
      <div class="cart-item-info">
        <h5 class="cart-item-title">${item.name}</h5>
        <div class="cart-item-variant">
          ${item.variant?.color ? item.variant.color : ''} ${item.variant?.size ? '• ' + item.variant.size : ''}
        </div>
        <div class="cart-item-price">${item.price * item.quantity} QAR</div>

        <div class="cart-item-actions">
          <div class="qty-control">
            <button class="qty-btn" onclick="updateQuantity(${idx}, -1)" aria-label="Decrease quantity">-</button>
            <span class="qty-val">${item.quantity}</span>
            <button class="qty-btn" onclick="updateQuantity(${idx}, 1)" aria-label="Increase quantity">+</button>
          </div>
          <button class="item-remove-btn" onclick="removeCartItem(${idx})">Remove</button>
        </div>
      </div>
    </div>
  `).join('');

  // Shipping cost logic
  let shippingCost = subtotal >= AppState.shippingThreshold ? 0 : AppState.standardShippingRate;
  let discountAmount = 0;

  if (AppState.appliedPromo) {
    const promo = AppState.promos[AppState.appliedPromo];
    if (promo.type === 'percent') {
      discountAmount = Math.round((subtotal * promo.value) / 100);
    } else if (promo.type === 'fixed') {
      discountAmount = Math.min(subtotal, promo.value);
    } else if (promo.type === 'shipping') {
      shippingCost = 0;
    }
  }

  const grandTotal = Math.max(0, subtotal - discountAmount + shippingCost);

  // Update summary fields
  const subtotalEl = document.getElementById('cartSubtotalAmount');
  const shippingEl = document.getElementById('cartShippingAmount');
  const discountRow = document.getElementById('cartDiscountRow');
  const discountEl = document.getElementById('cartDiscountAmount');
  const grandTotalEl = document.getElementById('cartGrandTotalAmount');

  if (subtotalEl) subtotalEl.textContent = `${subtotal} QAR`;
  if (shippingEl) shippingEl.textContent = shippingCost === 0 ? 'FREE' : `${shippingCost} QAR`;
  
  if (discountRow && discountEl) {
    if (discountAmount > 0) {
      discountRow.style.display = 'flex';
      discountEl.textContent = `-${discountAmount} QAR`;
    } else {
      discountRow.style.display = 'none';
    }
  }

  if (grandTotalEl) grandTotalEl.textContent = `${grandTotal} QAR`;
}

function applyCoupon(code) {
  if (AppState.promos[code]) {
    AppState.appliedPromo = code;
    showToast(`Promo "${code}" applied: ${AppState.promos[code].label}`, '🏷️');
    renderCart();
  } else {
    showToast(`Invalid promo code. Try "QATAR10"`, '⚠️');
  }
}

/* ==========================================================================
   7. WISHLIST SYSTEM
   ========================================================================== */
function toggleWishlist(productId, buttonElem) {
  const index = AppState.wishlist.indexOf(productId);
  const product = getProductById(productId);

  if (index > -1) {
    AppState.wishlist.splice(index, 1);
    if (buttonElem) {
      buttonElem.classList.remove('active');
      const svg = buttonElem.querySelector('svg');
      if (svg) svg.setAttribute('fill', 'none');
    }
    showToast(`Removed from Wishlist`, '🤍');
  } else {
    AppState.wishlist.push(productId);
    if (buttonElem) {
      buttonElem.classList.add('active');
      const svg = buttonElem.querySelector('svg');
      if (svg) svg.setAttribute('fill', 'currentColor');
    }
    showToast(`Saved to Wishlist: ${product?.name}`, '❤️');
  }

  saveState();
  updateWishlistBadge();
}

function updateWishlistBadge() {
  const badge = document.getElementById('wishlistCounterBadge');
  if (badge) {
    badge.textContent = AppState.wishlist.length;
    badge.style.display = AppState.wishlist.length > 0 ? 'flex' : 'none';
  }
}

/* ==========================================================================
   8. QUICK VIEW MODAL
   ========================================================================== */
function initQuickViewModal() {
  const modalOverlay = document.getElementById('quickViewModalOverlay');
  const closeBtn = document.getElementById('quickViewCloseBtn');

  if (closeBtn) {
    closeBtn.addEventListener('click', closeQuickView);
  }
}

function closeQuickView() {
  const modalOverlay = document.getElementById('quickViewModalOverlay');
  if (modalOverlay) {
    modalOverlay.classList.remove('active');
    document.body.style.overflow = '';
  }
}

function openProductQuickView(productId) {
  const product = getProductById(productId);
  if (!product) return;

  AppState.selectedProductForModal = product;
  const modalOverlay = document.getElementById('quickViewModalOverlay');
  const modalContent = document.getElementById('quickViewModalContent');

  if (!modalOverlay || !modalContent) return;

  let selectedColor = product.variants?.colors ? product.variants.colors[0] : null;
  let selectedSize = product.variants?.sizes ? product.variants.sizes[0] : null;
  let modalQty = 1;

  modalContent.innerHTML = `
    <div class="quickview-grid">
      <div class="quickview-media">
        <img class="quickview-main-img" id="quickViewImg" src="${product.image}" alt="${product.name}" />
      </div>

      <div class="quickview-details">
        <span class="badge badge-peach quickview-badge">${product.categoryName} • ${product.badge || 'IN STOCK'}</span>
        <h3 class="quickview-title">${product.name}</h3>

        <div class="product-rating" style="margin-bottom: 12px;">
          <div class="stars">${'★'.repeat(Math.floor(product.rating))}</div>
          <span>${product.rating.toFixed(1)} (${product.reviewsCount} verified Qatar reviews)</span>
        </div>

        <div class="quickview-prices">
          <span class="quickview-price-main">${product.price} QAR</span>
          ${product.originalPrice ? `<span class="price-original" style="font-size: 1.1rem;">${product.originalPrice} QAR</span>` : ''}
          <span class="badge badge-cream" style="font-size: 0.72rem;">Save ${product.originalPrice ? product.originalPrice - product.price : 0} QAR</span>
        </div>

        <p class="quickview-desc">${product.description}</p>

        <ul class="quickview-specs">
          ${product.specs.map(spec => `<li>✓ ${spec}</li>`).join('')}
          <li style="color: var(--c-forest); font-weight: 600;">🇶🇦 ${product.delivery}</li>
        </ul>

        ${product.variants?.colors ? `
          <div class="variant-group">
            <span class="variant-label">Select Color / Finish:</span>
            <div class="variant-options">
              ${product.variants.colors.map((c, i) => `
                <button class="variant-pill ${i === 0 ? 'active' : ''}" onclick="selectModalVariant(this, 'color', '${c}')">${c}</button>
              `).join('')}
            </div>
          </div>
        ` : ''}

        ${product.variants?.sizes ? `
          <div class="variant-group">
            <span class="variant-label">Select Size / Volume:</span>
            <div class="variant-options">
              ${product.variants.sizes.map((s, i) => `
                <button class="variant-pill ${i === 0 ? 'active' : ''}" onclick="selectModalVariant(this, 'size', '${s}')">${s}</button>
              `).join('')}
            </div>
          </div>
        ` : ''}

        <div class="quickview-footer-actions">
          <div class="qty-control" style="height: 48px; padding: 0 6px;">
            <button class="qty-btn" style="width: 32px; height: 32px;" onclick="adjustModalQty(-1)">-</button>
            <span class="qty-val" id="modalQtyDisplay" style="font-size: 1rem; min-width: 24px; text-align: center;">1</span>
            <button class="qty-btn" style="width: 32px; height: 32px;" onclick="adjustModalQty(1)">+</button>
          </div>

          <button class="btn btn-primary" style="flex: 1;" onclick="submitModalAddToCart('${product.id}')">
            Add to Bag • <span id="modalAddPrice">${product.price} QAR</span>
          </button>
        </div>
      </div>
    </div>
  `;

  modalOverlay.classList.add('active');
  document.body.style.overflow = 'hidden';
}

function selectModalVariant(elem, type, value) {
  elem.parentElement.querySelectorAll('.variant-pill').forEach(pill => pill.classList.remove('active'));
  elem.classList.add('active');
}

let currentModalQty = 1;
function adjustModalQty(delta) {
  currentModalQty = Math.max(1, currentModalQty + delta);
  const qtyEl = document.getElementById('modalQtyDisplay');
  const priceEl = document.getElementById('modalAddPrice');
  if (qtyEl) qtyEl.textContent = currentModalQty;
  if (priceEl && AppState.selectedProductForModal) {
    priceEl.textContent = `${AppState.selectedProductForModal.price * currentModalQty} QAR`;
  }
}

function submitModalAddToCart(productId) {
  const activeColorEl = document.querySelector('.variant-group:first-of-type .variant-pill.active');
  const activeSizeEl = document.querySelector('.variant-group:nth-of-type(2) .variant-pill.active');

  const variant = {
    color: activeColorEl ? activeColorEl.textContent.trim() : null,
    size: activeSizeEl ? activeSizeEl.textContent.trim() : null
  };

  addToCart(productId, currentModalQty, variant);
  closeQuickView();
  openCartDrawer();
  currentModalQty = 1;
}

/* ==========================================================================
   9. FULL CHECKOUT EXPERIENCE (Qatar Municipalities & Payments)
   ========================================================================== */
function initCheckoutModal() {
  const checkoutBtn = document.getElementById('proceedToCheckoutBtn');
  const checkoutOverlay = document.getElementById('checkoutModalOverlay');
  const checkoutClose = document.getElementById('checkoutCloseBtn');
  const checkoutForm = document.getElementById('checkoutForm');

  if (checkoutBtn) {
    checkoutBtn.addEventListener('click', () => {
      // Close cart drawer
      document.getElementById('cartDrawer').classList.remove('active');
      openCheckoutModal();
    });
  }

  if (checkoutClose) {
    checkoutClose.addEventListener('click', closeCheckout);
  }

  if (checkoutForm) {
    checkoutForm.addEventListener('submit', (e) => {
      e.preventDefault();
      processOrder();
    });
  }

  // Payment Option selection
  document.querySelectorAll('.payment-opt').forEach(opt => {
    opt.addEventListener('click', () => {
      document.querySelectorAll('.payment-opt').forEach(o => o.classList.remove('active'));
      opt.classList.add('active');
    });
  });
}

function openCheckoutModal() {
  const checkoutOverlay = document.getElementById('checkoutModalOverlay');
  if (!checkoutOverlay) return;

  // Populate checkout summary
  const subtotal = AppState.cart.reduce((sum, item) => sum + (item.price * item.quantity), 0);
  let shipping = subtotal >= AppState.shippingThreshold ? 0 : AppState.standardShippingRate;
  let discount = 0;

  if (AppState.appliedPromo) {
    const promo = AppState.promos[AppState.appliedPromo];
    if (promo.type === 'percent') discount = Math.round((subtotal * promo.value) / 100);
    else if (promo.type === 'fixed') discount = Math.min(subtotal, promo.value);
    else if (promo.type === 'shipping') shipping = 0;
  }

  const grandTotal = Math.max(0, subtotal - discount + shipping);

  const summaryEl = document.getElementById('checkoutSummaryItems');
  if (summaryEl) {
    summaryEl.innerHTML = AppState.cart.map(item => `
      <div style="display: flex; justify-content: space-between; font-size: 0.88rem; margin-bottom: 8px;">
        <span style="color: var(--c-charcoal); font-weight: 500;">${item.name} (x${item.quantity})</span>
        <span style="font-weight: 700; color: var(--c-forest);">${item.price * item.quantity} QAR</span>
      </div>
    `).join('') + `
      <div style="border-top: 1px solid var(--c-border); margin: 12px 0; padding-top: 12px;">
        <div style="display: flex; justify-content: space-between; font-size: 0.88rem; color: var(--c-charcoal-muted); margin-bottom: 6px;">
          <span>Subtotal</span>
          <span>${subtotal} QAR</span>
        </div>
        ${discount > 0 ? `
          <div style="display: flex; justify-content: space-between; font-size: 0.88rem; color: var(--c-peach-dark); margin-bottom: 6px;">
            <span>Discount (${AppState.appliedPromo})</span>
            <span>-${discount} QAR</span>
          </div>
        ` : ''}
        <div style="display: flex; justify-content: space-between; font-size: 0.88rem; color: var(--c-charcoal-muted); margin-bottom: 6px;">
          <span>Qatar Delivery</span>
          <span>${shipping === 0 ? 'FREE' : shipping + ' QAR'}</span>
        </div>
        <div style="display: flex; justify-content: space-between; font-size: 1.15rem; font-weight: 800; color: var(--c-forest); margin-top: 10px;">
          <span>Total to Pay</span>
          <span>${grandTotal} QAR</span>
        </div>
      </div>
    `;
  }

  checkoutOverlay.classList.add('active');
  document.body.style.overflow = 'hidden';
}

function closeCheckout() {
  const checkoutOverlay = document.getElementById('checkoutModalOverlay');
  if (checkoutOverlay) {
    checkoutOverlay.classList.remove('active');
    document.body.style.overflow = '';
  }
}

function processOrder() {
  const modalContent = document.getElementById('checkoutContentArea');
  const randomId = 'QA-' + Math.floor(100000 + Math.random() * 900000);
  
  // Clear cart
  AppState.cart = [];
  AppState.appliedPromo = null;
  saveState();
  updateCartBadge();

  if (modalContent) {
    modalContent.innerHTML = `
      <div class="order-success-box">
        <div class="order-success-icon">✓</div>
        <h3 class="order-success-title">Shukran! Your order is confirmed</h3>
        <p style="font-size: 1.05rem; color: var(--c-charcoal-muted); margin-bottom: 16px;">
          We are carefully preparing your items for delivery across Qatar.
        </p>
        <div class="order-id-badge">Order Reference: <strong>#WHO-${randomId}</strong></div>
        
        <div style="background: var(--c-cream); border-radius: var(--radius-md); padding: 20px; max-width: 480px; margin: 0 auto 28px; text-align: left; font-size: 0.9rem; line-height: 1.6;">
          <div style="margin-bottom: 8px;"><strong>Estimated Qatar Delivery:</strong> Within 24-48 Hours</div>
          <div style="margin-bottom: 8px;"><strong>Notification:</strong> SMS and WhatsApp dispatch tracking updates sent to your phone.</div>
          <div><strong>Payment:</strong> Confirmed & Secured</div>
        </div>

        <div style="display: flex; justify-content: center; gap: 14px; flex-wrap: wrap;">
          <button class="btn btn-primary" onclick="closeCheckout(); location.reload();">
            Continue Shopping
          </button>
          <a class="btn btn-secondary" href="https://wa.me/97400000000?text=Hi%20WHOohu%20Store%20Qatar%2C%20I%20have%20a%20question%20regarding%20my%20Order%20%23WHO-${randomId}" target="_blank">
            💬 WhatsApp Support
          </a>
        </div>
      </div>
    `;
  }
}

/* ==========================================================================
   10. COUNTDOWN TIMER (Doha Weekend Spotlight)
   ========================================================================== */
function initCountdown() {
  // Target: 48 hours from now
  let remainingSeconds = (48 * 3600) + (14 * 60) + 25;

  const daysEl = document.getElementById('countDays');
  const hoursEl = document.getElementById('countHours');
  const minsEl = document.getElementById('countMins');
  const secsEl = document.getElementById('countSecs');

  if (!daysEl || !hoursEl || !minsEl || !secsEl) return;

  setInterval(() => {
    if (remainingSeconds <= 0) return;
    remainingSeconds--;

    const d = Math.floor(remainingSeconds / (3600 * 24));
    const h = Math.floor((remainingSeconds % (3600 * 24)) / 3600);
    const m = Math.floor((remainingSeconds % 3600) / 60);
    const s = remainingSeconds % 60;

    daysEl.textContent = String(d).padStart(2, '0');
    hoursEl.textContent = String(h).padStart(2, '0');
    minsEl.textContent = String(m).padStart(2, '0');
    secsEl.textContent = String(s).padStart(2, '0');
  }, 1000);
}

/* ==========================================================================
   11. NEWSLETTER & TOASTS
   ========================================================================== */
function initNewsletter() {
  const form = document.getElementById('newsletterForm');
  if (form) {
    form.addEventListener('submit', (e) => {
      e.preventDefault();
      const input = document.getElementById('newsletterEmail');
      if (input && input.value) {
        showToast('Welcome to the Whoohu Club! Use code QATAR10 for 10% off', '🎁');
        input.value = '';
      }
    });
  }
}

function showToast(message, icon = '✨') {
  let container = document.getElementById('toastContainer');
  if (!container) {
    container = document.createElement('div');
    container.id = 'toastContainer';
    container.className = 'toast-container';
    document.body.appendChild(container);
  }

  const toast = document.createElement('div');
  toast.className = 'toast';
  toast.innerHTML = `
    <span class="toast-icon">${icon}</span>
    <span>${message}</span>
  `;

  container.appendChild(toast);

  setTimeout(() => {
    toast.style.opacity = '0';
    toast.style.transform = 'translateX(50px)';
    toast.style.transition = 'all 0.3s ease';
    setTimeout(() => toast.remove(), 300);
  }, 3200);
}

/* ==========================================================================
   12. THEME COLOR CUSTOMIZER ENGINE
   ========================================================================== */
const THEME_PRESETS = {
  forest: {
    name: 'Qatar Forest & Peach (Default)',
    primary: '#183C2B',
    accent: '#D98A72',
    bg: '#F8F5EE',
    beige: '#EDE7DC',
    charcoal: '#17211D'
  },
  navy: {
    name: 'Royal Navy & Champagne Gold',
    primary: '#0D1E2D',
    accent: '#C5A059',
    bg: '#F6F7F9',
    beige: '#E6EBF2',
    charcoal: '#0F1722'
  },
  terracotta: {
    name: 'Desert Sand & Terracotta',
    primary: '#3E2723',
    accent: '#D97757',
    bg: '#F9F6F0',
    beige: '#EFE8DE',
    charcoal: '#1F1614'
  },
  teal: {
    name: 'Doha Pearl Teal & Coral',
    primary: '#0D3B36',
    accent: '#E06D53',
    bg: '#F3F6F5',
    beige: '#DFE8E6',
    charcoal: '#112320'
  },
  charcoal: {
    name: 'Modern Onyx & Warm Amber',
    primary: '#14171A',
    accent: '#D99B26',
    bg: '#F7F7F4',
    beige: '#EAEAE5',
    charcoal: '#1A1D20'
  }
};

let currentTheme = { ...THEME_PRESETS.forest };

function initThemeCustomizer() {
  // Load saved theme if any
  const saved = localStorage.getItem('whoohu_theme');
  if (saved) {
    try {
      const parsed = JSON.parse(saved);
      applyThemeColors(parsed, false);
      currentTheme = parsed;
    } catch(e) {}
  }

  // Bind trigger button
  const trigger = document.getElementById('themeTriggerBtn');
  const overlay = document.getElementById('themeModalOverlay');
  const closeBtn = document.getElementById('themeCloseBtn');

  if (trigger && overlay) {
    trigger.addEventListener('click', () => {
      openThemeModal();
    });

    if (closeBtn) {
      closeBtn.addEventListener('click', () => {
        overlay.classList.remove('active');
        document.body.style.overflow = '';
      });
    }
  }

  // Render presets
  renderThemePresets();
  initColorPickers();
  updateThemeCodeDisplay();
}

function openThemeModal() {
  const overlay = document.getElementById('themeModalOverlay');
  if (overlay) {
    overlay.classList.add('active');
    document.body.style.overflow = 'hidden';
    updateThemeCodeDisplay();
  }
}

function renderThemePresets() {
  const container = document.getElementById('themePresetsGrid');
  if (!container) return;

  container.innerHTML = Object.entries(THEME_PRESETS).map(([key, p]) => `
    <div class="preset-card ${currentTheme.primary === p.primary ? 'active' : ''}" onclick="selectThemePreset('${key}')">
      <div>
        <div class="preset-name">${p.name}</div>
        <div class="preset-swatches">
          <span class="preset-swatch" style="background-color: ${p.primary};" title="Primary"></span>
          <span class="preset-swatch" style="background-color: ${p.accent};" title="Accent"></span>
          <span class="preset-swatch" style="background-color: ${p.bg}; border: 1px solid #ccc;" title="Background"></span>
        </div>
      </div>
    </div>
  `).join('');
}

function selectThemePreset(key) {
  const preset = THEME_PRESETS[key];
  if (!preset) return;

  applyThemeColors(preset, true);
  currentTheme = { ...preset };
  
  // Update inputs
  const pInput = document.getElementById('primaryColorInput');
  const aInput = document.getElementById('accentColorInput');
  const bInput = document.getElementById('bgColorInput');
  if (pInput) { pInput.value = preset.primary; document.getElementById('primaryHexVal').textContent = preset.primary; }
  if (aInput) { aInput.value = preset.accent; document.getElementById('accentHexVal').textContent = preset.accent; }
  if (bInput) { bInput.value = preset.bg; document.getElementById('bgHexVal').textContent = preset.bg; }

  renderThemePresets();
  updateThemeCodeDisplay();
  showToast(`Applied ${preset.name} theme!`, '🎨');
}

function initColorPickers() {
  const pInput = document.getElementById('primaryColorInput');
  const aInput = document.getElementById('accentColorInput');
  const bInput = document.getElementById('bgColorInput');

  if (pInput) {
    pInput.value = currentTheme.primary;
    document.getElementById('primaryHexVal').textContent = currentTheme.primary;
    pInput.addEventListener('input', (e) => {
      currentTheme.primary = e.target.value;
      document.getElementById('primaryHexVal').textContent = e.target.value;
      applyThemeColors(currentTheme, true);
      updateThemeCodeDisplay();
    });
  }

  if (aInput) {
    aInput.value = currentTheme.accent;
    document.getElementById('accentHexVal').textContent = currentTheme.accent;
    aInput.addEventListener('input', (e) => {
      currentTheme.accent = e.target.value;
      document.getElementById('accentHexVal').textContent = e.target.value;
      applyThemeColors(currentTheme, true);
      updateThemeCodeDisplay();
    });
  }

  if (bInput) {
    bInput.value = currentTheme.bg;
    document.getElementById('bgHexVal').textContent = currentTheme.bg;
    bInput.addEventListener('input', (e) => {
      currentTheme.bg = e.target.value;
      document.getElementById('bgHexVal').textContent = e.target.value;
      applyThemeColors(currentTheme, true);
      updateThemeCodeDisplay();
    });
  }

  const copyBtn = document.getElementById('copyThemeCssBtn');
  if (copyBtn) {
    copyBtn.addEventListener('click', () => {
      const code = generateThemeCss();
      navigator.clipboard.writeText(code).then(() => {
        showToast('CSS variables copied to clipboard!', '📋');
      });
    });
  }
}

function applyThemeColors(theme, save = true) {
  const root = document.documentElement;
  root.style.setProperty('--c-forest', theme.primary);
  root.style.setProperty('--c-forest-dark', shadeColor(theme.primary, -20));
  root.style.setProperty('--c-forest-light', shadeColor(theme.primary, 15));
  root.style.setProperty('--c-forest-soft', hexToRgba(theme.primary, 0.08));

  root.style.setProperty('--c-peach', theme.accent);
  root.style.setProperty('--c-peach-dark', shadeColor(theme.accent, -15));
  root.style.setProperty('--c-peach-light', hexToRgba(theme.accent, 0.12));
  root.style.setProperty('--c-peach-glow', hexToRgba(theme.accent, 0.3));

  root.style.setProperty('--c-cream', theme.bg);
  root.style.setProperty('--c-cream-dark', shadeColor(theme.bg, -4));

  if (save) {
    localStorage.setItem('whoohu_theme', JSON.stringify(theme));
  }
}

function updateThemeCodeDisplay() {
  const el = document.getElementById('themeCodeDisplay');
  if (el) {
    el.textContent = generateThemeCss();
  }
}

function generateThemeCss() {
  return `/* Paste in styles/main.css under :root */
:root {
  --c-forest: ${currentTheme.primary};
  --c-peach: ${currentTheme.accent};
  --c-cream: ${currentTheme.bg};
}`;
}

// Color Utility Helpers
function shadeColor(color, percent) {
  let num = parseInt(color.replace('#', ''), 16),
  amt = Math.round(2.55 * percent),
  R = (num >> 16) + amt,
  B = ((num >> 8) & 0x00FF) + amt,
  G = (num & 0x0000FF) + amt;
  return '#' + (0x1000000 + (R < 255 ? (R < 1 ? 0 : R) : 255) * 0x10000 + (B < 255 ? (B < 1 ? 0 : B) : 255) * 0x100 + (G < 255 ? (G < 1 ? 0 : G) : 255)).toString(16).slice(1);
}

function hexToRgba(hex, alpha) {
  let c = hex.replace('#', '');
  if (c.length === 3) c = c.split('').map(x => x + x).join('');
  let num = parseInt(c, 16);
  return `rgba(${(num >> 16) & 255}, ${(num >> 8) & 255}, ${num & 255}, ${alpha})`;
}


