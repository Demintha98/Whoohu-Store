/**
 * Whoohu Store - Product Catalog
 * Curated for Qatar Shoppers
 * Prices in QAR (Qatari Riyal)
 */

const WHOOHU_PRODUCTS = [
  // FASHION
  {
    id: "f-1",
    name: "Silk Linen Resort Abaya & Slip Set",
    category: "fashion",
    categoryName: "Fashion",
    price: 480,
    originalPrice: 590,
    rating: 4.9,
    reviewsCount: 86,
    badge: "BESTSELLER",
    featured: true,
    trending: true,
    newArrival: false,
    image: "https://images.unsplash.com/photo-1515886657613-9f3515b0c78f?auto=format&fit=crop&w=800&q=80",
    hoverImage: "https://images.unsplash.com/photo-1509631179647-0177331693ae?auto=format&fit=crop&w=800&q=80",
    description: "An ethereal blend of pure mulberry silk and lightweight organic linen. Crafted for Doha's warm breeze and elegant evening gatherings, featuring a cascading drape and matching slip dress.",
    specs: ["Fabric: 45% Silk, 55% French Linen", "Length: Tailored 56-58 inches", "Includes matching inner slip dress", "Dry clean or gentle cold hand wash"],
    variants: {
      colors: ["Sand Beige", "Sage Olive", "Midnight Black"],
      sizes: ["S (52)", "M (54)", "L (56)", "XL (58)"]
    },
    inStock: true,
    stockCount: 14,
    delivery: "Same-Day Delivery in Doha & Lusail"
  },
  {
    id: "f-2",
    name: "Florentine Leather Crossbody Saddle Bag",
    category: "fashion",
    categoryName: "Fashion",
    price: 395,
    originalPrice: 480,
    rating: 4.8,
    reviewsCount: 42,
    badge: "NEW IN",
    featured: true,
    trending: true,
    newArrival: true,
    image: "https://images.unsplash.com/photo-1548036328-c9fa89d128fa?auto=format&fit=crop&w=800&q=80",
    hoverImage: "https://images.unsplash.com/photo-1590874103328-eac38a683ce7?auto=format&fit=crop&w=800&q=80",
    description: "Artisanal full-grain Italian leather with hand-burnished edges and brushed champagne gold hardware. Includes an adjustable strap and dual interior magnetic compartments.",
    specs: ["100% Full-grain calfskin leather", "Dimensions: 22cm x 17cm x 7cm", "Gold-tone custom hardware", "Includes dust bag and care balm"],
    variants: {
      colors: ["Cognac Tan", "Noir Black", "Forest Green"],
      sizes: ["One Size"]
    },
    inStock: true,
    stockCount: 8,
    delivery: "Next-Day Delivery across Qatar"
  },
  {
    id: "f-3",
    name: "Bespoke Linen-Blend Relaxed Overshirt",
    category: "fashion",
    categoryName: "Fashion",
    price: 260,
    originalPrice: 320,
    rating: 4.7,
    reviewsCount: 38,
    badge: "POPULAR",
    featured: false,
    trending: false,
    newArrival: true,
    image: "https://images.unsplash.com/photo-1598033129183-c4f50c736f10?auto=format&fit=crop&w=800&q=80",
    hoverImage: "https://images.unsplash.com/photo-1602810318383-e386cc2a3ccf?auto=format&fit=crop&w=800&q=80",
    description: "Effortless casual tailoring cut from breathable Belgian linen-cotton. Features natural corozo buttons, double chest pockets, and a modern relaxed drop shoulder silhouette.",
    specs: ["60% Belgian Linen, 40% Long-staple Cotton", "Natural unbleached corozo buttons", "Pre-washed for zero shrinkage", "Machine wash cold"],
    variants: {
      colors: ["Oatmeal Cream", "Deep Forest", "Terracotta"],
      sizes: ["S", "M", "L", "XL", "XXL"]
    },
    inStock: true,
    stockCount: 19,
    delivery: "Fast Qatar-Wide Delivery"
  },
  {
    id: "f-4",
    name: "Cashmere & Mulberry Silk Ombré Scarf",
    category: "fashion",
    categoryName: "Fashion",
    price: 220,
    originalPrice: 280,
    rating: 4.9,
    reviewsCount: 64,
    badge: "QATAR EXCLUSIVE",
    featured: false,
    trending: true,
    newArrival: false,
    image: "https://images.unsplash.com/photo-1601924994987-69e26d50dc26?auto=format&fit=crop&w=800&q=80",
    hoverImage: "https://images.unsplash.com/photo-1520903920243-00d872a2d1c9?auto=format&fit=crop&w=800&q=80",
    description: "Featherlight luxury woven from Grade-A Mongolian cashmere and fine mulberry silk. Hand-dipped ombré gradient inspired by the shifting sands of the Qatar Inland Sea.",
    specs: ["70% Cashmere, 30% Mulberry Silk", "Dimensions: 200cm x 70cm", "Hand-rolled eyelash fringes", "Presented in signature Whoohu gift sleeve"],
    variants: {
      colors: ["Dusk Rose to Peach", "Desert Dune Gold", "Emerald to Sage"],
      sizes: ["Standard"]
    },
    inStock: true,
    stockCount: 12,
    delivery: "Same-Day Delivery in Doha"
  },
  {
    id: "f-5",
    name: "Minimalist 18k Gold Vermeil Bangle Trio",
    category: "fashion",
    categoryName: "Fashion",
    price: 185,
    originalPrice: 230,
    rating: 4.8,
    reviewsCount: 51,
    badge: "TRENDING",
    featured: false,
    trending: true,
    newArrival: true,
    image: "https://images.unsplash.com/photo-1535632066927-ab7c9ab60908?auto=format&fit=crop&w=800&q=80",
    hoverImage: "https://images.unsplash.com/photo-1599643478518-a784e5dc4c8f?auto=format&fit=crop&w=800&q=80",
    description: "A harmonious stack of three interlocking textured bracelets crafted in durable 18k yellow gold vermeil over recycled sterling silver. Hypoallergenic and water-resistant.",
    specs: ["18k Yellow Gold Vermeil (2.5 microns)", "Base: 925 Sterling Silver", "Inner diameter: 62mm", "Tarnish-free protective nano-coating"],
    variants: {
      colors: ["18k Yellow Gold", "Warm Rose Gold", "Sterling Silver"],
      sizes: ["Standard Fit"]
    },
    inStock: true,
    stockCount: 22,
    delivery: "Fast Qatar-Wide Delivery"
  },

  // BEAUTY
  {
    id: "b-1",
    name: "Royal Amber & Taif Rose Extrait de Parfum",
    category: "beauty",
    categoryName: "Beauty",
    price: 520,
    originalPrice: 650,
    rating: 5.0,
    reviewsCount: 112,
    badge: "LUXURY PICK",
    featured: true,
    trending: true,
    newArrival: false,
    image: "https://images.unsplash.com/photo-1592945403244-b3fbafd7f539?auto=format&fit=crop&w=800&q=80",
    hoverImage: "https://images.unsplash.com/photo-1547887537-6158d64c35b3?auto=format&fit=crop&w=800&q=80",
    description: "A majestic olfactory tribute to Arabian perfumery. Rare Taif rose petals distilled with aged Cambodian amber, smoked saffron, and creamy Madagascar bourbon vanilla.",
    specs: ["Concentration: 32% Extrait de Parfum", "Volume: 100ml / 3.4 fl oz", "Longevity: 14+ hours on skin", "Heavy glass flacon with magnetic brass cap"],
    variants: {
      colors: ["100ml Full Flacon", "50ml Travel Flacon"],
      sizes: ["Extrait de Parfum"]
    },
    inStock: true,
    stockCount: 9,
    delivery: "Same-Day Delivery in Doha & Lusail"
  },
  {
    id: "b-2",
    name: "Saffron Glow Radiance Recovery Face Elixir",
    category: "beauty",
    categoryName: "Beauty",
    price: 275,
    originalPrice: 340,
    rating: 4.9,
    reviewsCount: 79,
    badge: "BESTSELLER",
    featured: true,
    trending: false,
    newArrival: false,
    image: "https://images.unsplash.com/photo-1620916566398-39f1143ab7be?auto=format&fit=crop&w=800&q=80",
    hoverImage: "https://images.unsplash.com/photo-1601049541289-9b1b7bbbfe19?auto=format&fit=crop&w=800&q=80",
    description: "Infused with pure organic saffron stigmas, cold-pressed rosehip seed oil, and botanical squalane. Restores deep hydration, illuminates dull skin, and guards against environmental stress.",
    specs: ["30ml / 1.0 fl oz dropper bottle", "100% Cold-pressed & Organic", "Free from parabens, sulfates & synthetics", "Safe for all skin types, including sensitive"],
    variants: {
      colors: ["30ml Standard", "50ml Jumbo"],
      sizes: ["Glass Dropper"]
    },
    inStock: true,
    stockCount: 17,
    delivery: "Fast Qatar-Wide Delivery"
  },
  {
    id: "b-3",
    name: "Camel Milk & Sidr Honey Hydrating Mask",
    category: "beauty",
    categoryName: "Beauty",
    price: 190,
    originalPrice: 235,
    rating: 4.8,
    reviewsCount: 58,
    badge: "ORGANIC",
    featured: false,
    trending: true,
    newArrival: true,
    image: "https://images.unsplash.com/photo-1556228720-195a672e8a03?auto=format&fit=crop&w=800&q=80",
    hoverImage: "https://images.unsplash.com/photo-1571781926291-c477ebfd024b?auto=format&fit=crop&w=800&q=80",
    description: "A velvety whipped treatment harnessing the natural alpha-hydroxy acids of pastoral camel milk and antioxidant-rich Yemeni Sidr honey to plump and deeply revitalize tired skin.",
    specs: ["Volume: 100g / 3.5 oz", "Natural lactic acid & active vitamins C, B, D", "Use 2-3 times weekly for 15 minutes", "Dermatologically tested in France"],
    variants: {
      colors: ["100g Jar"],
      sizes: ["Full Size"]
    },
    inStock: true,
    stockCount: 25,
    delivery: "Fast Qatar-Wide Delivery"
  },
  {
    id: "b-4",
    name: "Velvet Bakhoor Botanical Body Soufflé",
    category: "beauty",
    categoryName: "Beauty",
    price: 165,
    originalPrice: 210,
    rating: 4.7,
    reviewsCount: 46,
    badge: "NEW IN",
    featured: false,
    trending: false,
    newArrival: true,
    image: "https://images.unsplash.com/photo-1522337360788-8b13dee7a37e?auto=format&fit=crop&w=800&q=80",
    hoverImage: "https://images.unsplash.com/photo-1598440947619-2c35fc9aa908?auto=format&fit=crop&w=800&q=80",
    description: "Ultra-hydrating body cream whipped with fair-trade African shea butter, sweet almond oil, and subtly kissed by authentic warm bakhoor smoke and white musk.",
    specs: ["Volume: 250ml / 8.5 oz", "24-hour moisture lock formula", "Non-greasy, fast-absorbing texture", "Subtle lingering Arabian scent"],
    variants: {
      colors: ["250ml Glass Jar"],
      sizes: ["Standard"]
    },
    inStock: true,
    stockCount: 31,
    delivery: "Fast Qatar-Wide Delivery"
  },
  {
    id: "b-5",
    name: "Rose Quartz Sculpting Gua Sha & Roller Duo",
    category: "beauty",
    categoryName: "Beauty",
    price: 140,
    originalPrice: 180,
    rating: 4.8,
    reviewsCount: 93,
    badge: "POPULAR",
    featured: false,
    trending: true,
    newArrival: false,
    image: "https://images.unsplash.com/photo-1590439471364-192aa70c0b53?auto=format&fit=crop&w=800&q=80",
    hoverImage: "https://images.unsplash.com/photo-1617897903246-719242758050?auto=format&fit=crop&w=800&q=80",
    description: "Carved from 100% authentic Brazilian pink rose quartz. Promotes lymphatic drainage, relieves facial muscle tension, and enhances serum penetration for an enviable sculpted jawline.",
    specs: ["Grade-AAA authentic natural rose quartz", "Reinforced zinc alloy frame (no squeaks)", "Comes with velvet travel pouch and tutorial guide"],
    variants: {
      colors: ["Rose Quartz Pink", "Emerald Green Jade"],
      sizes: ["Duo Set"]
    },
    inStock: true,
    stockCount: 40,
    delivery: "Fast Qatar-Wide Delivery"
  },

  // GADGETS
  {
    id: "g-1",
    name: "Aura Pro Wireless ANC Studio Headphones",
    category: "gadgets",
    categoryName: "Gadgets",
    price: 680,
    originalPrice: 820,
    rating: 4.9,
    reviewsCount: 140,
    badge: "TOP RATED",
    featured: true,
    trending: true,
    newArrival: false,
    image: "https://images.unsplash.com/photo-1505740420928-5e560c06d30e?auto=format&fit=crop&w=800&q=80",
    hoverImage: "https://images.unsplash.com/photo-1484704849700-f032a568e944?auto=format&fit=crop&w=800&q=80",
    description: "Architectural minimalism meets audiophile precision. Dual custom 40mm beryllium drivers, active hybrid noise cancellation (up to -42dB), and plush memory foam protein leather cushions.",
    specs: ["Active Noise Cancellation with Transparency Mode", "42-hour battery life (Quick Charge: 10m = 5h)", "Bluetooth 5.3 with LDAC / AAC high-res codecs", "Aircraft-grade anodized aluminum frame"],
    variants: {
      colors: ["Matte Charcoal", "Sand Dune Beige", "Forest Spruce"],
      sizes: ["Over-Ear Studio"]
    },
    inStock: true,
    stockCount: 11,
    delivery: "Same-Day Delivery in Doha & Lusail"
  },
  {
    id: "g-2",
    name: "MagCharge 3-in-1 Foldable Walnut Charging Dock",
    category: "gadgets",
    categoryName: "Gadgets",
    price: 310,
    originalPrice: 380,
    rating: 4.8,
    reviewsCount: 88,
    badge: "BESTSELLER",
    featured: true,
    trending: true,
    newArrival: false,
    image: "https://images.unsplash.com/photo-1586816879360-004f5b0c51e5?auto=format&fit=crop&w=800&q=80",
    hoverImage: "https://images.unsplash.com/photo-1588872657578-7efd1f1555ed?auto=format&fit=crop&w=800&q=80",
    description: "Sustainably sourced North American walnut wood inlaid with precision MagSafe magnets. Charges iPhone, Apple Watch, and AirPods simultaneously with a single clean USB-C cable.",
    specs: ["15W Qi2 Fast Wireless MagSafe charging", "Folds completely flat for travel", "Solid FSC-certified walnut wood finish", "Includes 35W braided USB-C power brick"],
    variants: {
      colors: ["Natural Walnut & Silver", "Black Ash & Dark Bronze"],
      sizes: ["Compact Foldable"]
    },
    inStock: true,
    stockCount: 23,
    delivery: "Fast Qatar-Wide Delivery"
  },
  {
    id: "g-3",
    name: "Nordic Minimalist Cordless Ambient Lantern",
    category: "gadgets",
    categoryName: "Gadgets",
    price: 240,
    originalPrice: 295,
    rating: 4.9,
    reviewsCount: 62,
    badge: "TRENDING",
    featured: false,
    trending: true,
    newArrival: true,
    image: "https://images.unsplash.com/photo-1507473885765-e6ed057f782c?auto=format&fit=crop&w=800&q=80",
    hoverImage: "https://images.unsplash.com/photo-1513506003901-1e6a229e2d15?auto=format&fit=crop&w=800&q=80",
    description: "Portable rechargeable light inspired by Scandinavian warmth. Features step-less touch dimming from warm candlelight (2200K) to crisp reading glow (3000K) with 20h cordless life.",
    specs: ["IP54 water & dust resistance (indoor/outdoor terrace use)", "USB-C rechargeable 5200mAh battery", "Die-cast powder-coated aluminum handle", "Smooth capacitive touch switch"],
    variants: {
      colors: ["Forest Green", "Brushed Brass", "Warm Cream"],
      sizes: ["Medium (24cm)"]
    },
    inStock: true,
    stockCount: 16,
    delivery: "Fast Qatar-Wide Delivery"
  },
  {
    id: "g-4",
    name: "Retro Mechanical Dual-Mode Wireless Keyboard",
    category: "gadgets",
    categoryName: "Gadgets",
    price: 420,
    originalPrice: 490,
    rating: 4.8,
    reviewsCount: 53,
    badge: "NEW IN",
    featured: false,
    trending: false,
    newArrival: true,
    image: "https://images.unsplash.com/photo-1587829741301-dc798b83add3?auto=format&fit=crop&w=800&q=80",
    hoverImage: "https://images.unsplash.com/photo-1618384887929-16ec33fab9ef?auto=format&fit=crop&w=800&q=80",
    description: "Compact 75% mechanical keyboard with tactile butter-smooth pre-lubed switches, PBT dye-sub keycaps, and multi-device pairing across Mac, Windows, and iPad via Bluetooth 5.1 or 2.4G.",
    specs: ["Hot-swappable tactile ivory switches", "Connect up to 3 devices simultaneously", "4000mAh battery (up to 200 hours backlight off)", "Aluminum alloy top plate with brass rotary knob"],
    variants: {
      colors: ["Cream & Sage Green", "Chalk White & Charcoal"],
      sizes: ["75% Compact"]
    },
    inStock: true,
    stockCount: 10,
    delivery: "Fast Qatar-Wide Delivery"
  },
  {
    id: "g-5",
    name: "AromaMist Ultrasonic Smart Desktop Diffuser",
    category: "gadgets",
    categoryName: "Gadgets",
    price: 195,
    originalPrice: 250,
    rating: 4.7,
    reviewsCount: 67,
    badge: "HOT PICK",
    featured: false,
    trending: true,
    newArrival: false,
    image: "https://images.unsplash.com/photo-1608571423902-eed4a5ad8108?auto=format&fit=crop&w=800&q=80",
    hoverImage: "https://images.unsplash.com/photo-1519710164239-da123dc03ef4?auto=format&fit=crop&w=800&q=80",
    description: "Whisper-quiet ultrasonic diffusion (under 20dB) paired with natural ceramic housing and warm ambient flame-mimicking LED light. Automatically shuts off when water is depleted.",
    specs: ["280ml water tank (8-10 hours continuous mist)", "Auto safety shut-off sensor", "BPA-free medical-grade materials", "Compatible with pure essential oils and oud drops"],
    variants: {
      colors: ["Ceramic Beige", "Charcoal Slate"],
      sizes: ["Standard"]
    },
    inStock: true,
    stockCount: 29,
    delivery: "Fast Qatar-Wide Delivery"
  },

  // HOME & KITCHEN
  {
    id: "h-1",
    name: "Artisanal Ceramic Stoneware Dinner Set (16-Pc)",
    category: "home",
    categoryName: "Home & Kitchen",
    price: 560,
    originalPrice: 690,
    rating: 4.9,
    reviewsCount: 74,
    badge: "BESTSELLER",
    featured: true,
    trending: true,
    newArrival: false,
    image: "https://images.unsplash.com/photo-1610701596007-11502861dcfa?auto=format&fit=crop&w=800&q=80",
    hoverImage: "https://images.unsplash.com/photo-1578749556568-bc2c40e68b61?auto=format&fit=crop&w=800&q=80",
    description: "Hand-thrown Portuguese stoneware finished with organic reactive glaze. Service for 4 including dinner plates, salad bowls, dessert plates, and artisanal coffee mugs.",
    specs: ["Microwave, dishwasher, and oven safe up to 220°C", "Scratch-resistant matte exterior with satin interior", "Includes 4x Dinner Plates (27cm), 4x Salad Plates (21cm), 4x Bowls, 4x Mugs", "Lead-free & non-toxic"],
    variants: {
      colors: ["Warm Oatmeal Glaze", "Sage Mist Green", "Terracotta Clay"],
      sizes: ["16-Piece Service for 4"]
    },
    inStock: true,
    stockCount: 7,
    delivery: "Free Delivery in Qatar (Fragile White-Glove)"
  },
  {
    id: "h-2",
    name: "Hammered Solid Brass Arabic Dallah & Cup Set",
    category: "home",
    categoryName: "Home & Kitchen",
    price: 380,
    originalPrice: 460,
    rating: 5.0,
    reviewsCount: 83,
    badge: "HERITAGE PICK",
    featured: true,
    trending: false,
    newArrival: false,
    image: "https://images.unsplash.com/photo-1544787219-7f47ccb76574?auto=format&fit=crop&w=800&q=80",
    hoverImage: "https://images.unsplash.com/photo-1514432324607-a09d9b4aefdd?auto=format&fit=crop&w=800&q=80",
    description: "A cherished symbol of Qatari hospitality. Mastercrafted from pure solid brass with traditional hammered relief patterns, accompanied by six porcelain finjan cups with matching gilded rims.",
    specs: ["Capacity: 950ml traditional Dallah", "Includes 6x Fine Porcelain Finjan cups", "Food-safe tin-lined interior for authentic Gahwa preparation", "Presentation gift box included"],
    variants: {
      colors: ["Polished Brass & Gold", "Antique Patina Brass"],
      sizes: ["Complete 7-Piece Set"]
    },
    inStock: true,
    stockCount: 15,
    delivery: "Same-Day Delivery in Doha"
  },
  {
    id: "h-3",
    name: "Wabi-Sabi Sculptural Textured Terracotta Vase",
    category: "home",
    categoryName: "Home & Kitchen",
    price: 215,
    originalPrice: 270,
    rating: 4.8,
    reviewsCount: 49,
    badge: "EDITORIAL",
    featured: false,
    trending: true,
    newArrival: true,
    image: "https://images.unsplash.com/photo-1578500494198-246f612d3b3d?auto=format&fit=crop&w=800&q=80",
    hoverImage: "https://images.unsplash.com/photo-1581783342308-f792dbdd27c5?auto=format&fit=crop&w=800&q=80",
    description: "An evocative centerpiece celebrating raw texture and organic asymmetry. Hand-sculpted by ceramic artisans with natural sand wash, perfect for dried pampas or fresh blooms.",
    specs: ["Height: 32cm, Diameter: 18cm", "Waterproof sealed interior", "Felt padded base prevents tabletop scratching"],
    variants: {
      colors: ["Sand Textured White", "Desert Clay Brown"],
      sizes: ["Tall Sculptural"]
    },
    inStock: true,
    stockCount: 20,
    delivery: "Fast Qatar-Wide Delivery"
  },
  {
    id: "h-4",
    name: "Pure French Flax Linen Bedding Duvet Set",
    category: "home",
    categoryName: "Home & Kitchen",
    price: 640,
    originalPrice: 780,
    rating: 4.9,
    reviewsCount: 91,
    badge: "LUXURY",
    featured: false,
    trending: true,
    newArrival: false,
    image: "https://images.unsplash.com/photo-1522771739844-6a9f6d5f14af?auto=format&fit=crop&w=800&q=80",
    hoverImage: "https://images.unsplash.com/photo-1584100936595-c0654b55a2e2?auto=format&fit=crop&w=800&q=80",
    description: "Woven from 100% certified French flax linen. Pre-washed with volcanic stones for extraordinary softness that gets even more supple with every wash. Naturally thermoregulating.",
    specs: ["100% French Flax Linen (175 GSM)", "Set includes: 1x Duvet Cover + 2x Pillow Shams", "Internal corner ties & concealed mother-of-pearl buttons", "OEKO-TEX Standard 100 certified"],
    variants: {
      colors: ["Warm Cream & Almond", "Forest Moss", "Soft Peach Terracotta"],
      sizes: ["Queen (200x200cm)", "King (240x220cm)", "Super King (260x240cm)"]
    },
    inStock: true,
    stockCount: 6,
    delivery: "Fast Qatar-Wide Delivery"
  },
  {
    id: "h-5",
    name: "Enameled Cast Iron Dutch Oven with Brass Knob (5.5L)",
    category: "home",
    categoryName: "Home & Kitchen",
    price: 450,
    originalPrice: 550,
    rating: 4.9,
    reviewsCount: 63,
    badge: "POPULAR",
    featured: false,
    trending: false,
    newArrival: true,
    image: "https://images.unsplash.com/photo-1544233726-9f1d2b27be8b?auto=format&fit=crop&w=800&q=80",
    hoverImage: "https://images.unsplash.com/photo-1590794056226-79ef3a8147e1?auto=format&fit=crop&w=800&q=80",
    description: "Heirloom-grade heavy cast iron with multi-coat glass enamel. Delivers superior heat retention and self-basting lid spikes for slow-cooked Machboos, braises, and artisan sourdough.",
    specs: ["Capacity: 5.5 Liters (serves 5-7)", "Oven safe up to 260°C / 500°F", "Compatible with Induction, Gas, Electric & Ceramic hobs", "Solid brushed brass signature knob"],
    variants: {
      colors: ["Forest Emerald Green", "Warm Cream Linen", "Deep Matte Navy"],
      sizes: ["5.5 Liter (26cm)"]
    },
    inStock: true,
    stockCount: 13,
    delivery: "Fast Qatar-Wide Delivery"
  },

  // GIFTS
  {
    id: "gift-1",
    name: "The Doha Royal Heritage Keepsake Gift Hamper",
    category: "gifts",
    categoryName: "Gifts",
    price: 750,
    originalPrice: 890,
    rating: 5.0,
    reviewsCount: 115,
    badge: "SIGNATURE GIFT",
    featured: true,
    trending: true,
    newArrival: false,
    image: "https://images.unsplash.com/photo-1549465220-1a8b9238cd48?auto=format&fit=crop&w=800&q=80",
    hoverImage: "https://images.unsplash.com/photo-1513885535751-8b9238bd345a?auto=format&fit=crop&w=800&q=80",
    description: "Our crowning gift presentation for weddings, Ramadan, Eid, and VIP milestones. Handcrafted velvet trunk filled with aged Taif rose oud oil, stuffed Medjool dates, an ornate brass burner, and custom card.",
    specs: ["Hand-crafted forest green velvet trunk with brass lock", "Includes 30ml pure Amber & Rose perfume oil", "500g Luxury Medjool dates stuffed with roasted almonds & candied orange", "Hand-cast brass incense burner + charcoal tongs", "Complimentary personalized calligraphy card"],
    variants: {
      colors: ["Emerald Green Velvet Trunk", "Royal Ivory Trunk"],
      sizes: ["Deluxe Grand Hamper"]
    },
    inStock: true,
    stockCount: 9,
    delivery: "Same-Day Hand-Delivery in Doha & Lusail"
  },
  {
    id: "gift-2",
    name: "Curated Soy Candle & Brass Wick Trimmer Gift Set",
    category: "gifts",
    categoryName: "Gifts",
    price: 240,
    originalPrice: 300,
    rating: 4.9,
    reviewsCount: 72,
    badge: "BESTSELLER",
    featured: false,
    trending: true,
    newArrival: false,
    image: "https://images.unsplash.com/photo-1603006905003-be475563bc59?auto=format&fit=crop&w=800&q=80",
    hoverImage: "https://images.unsplash.com/photo-1572726729437-3732efc7429c?auto=format&fit=crop&w=800&q=80",
    description: "Two 300g hand-poured natural soy wax candles featuring scents of 'Doha Jasmine & White Fig' and 'Smoked Oud & Warm Amber', paired with an elegant brushed brass wick trimmer.",
    specs: ["100% Non-GMO coconut-soy wax blend", "Burn time: 65 hours per candle", "Pure cotton lead-free double wicks", "Matte ceramic vessels with wood lids"],
    variants: {
      colors: ["Doha Nights Duo (Jasmine & Oud)", "Desert Sunrise Duo (Amber & Citrus)"],
      sizes: ["Duo Gift Box"]
    },
    inStock: true,
    stockCount: 35,
    delivery: "Fast Qatar-Wide Delivery"
  },
  {
    id: "gift-3",
    name: "Custom Monogrammed Leather Passport & Tag Duo",
    category: "gifts",
    categoryName: "Gifts",
    price: 210,
    originalPrice: 260,
    rating: 4.8,
    reviewsCount: 56,
    badge: "PERSONALIZED",
    featured: false,
    trending: false,
    newArrival: true,
    image: "https://images.unsplash.com/photo-1544816155-12df9643f363?auto=format&fit=crop&w=800&q=80",
    hoverImage: "https://images.unsplash.com/photo-1527631746610-bca00a040d60?auto=format&fit=crop&w=800&q=80",
    description: "Handmade vegetable-tanned top-grain leather passport case and matching luggage tag. Free custom hot-foil monogramming in gold, silver, or blind deboss (up to 4 letters).",
    specs: ["Top-grain Italian vegetable-tanned leather", "RFID-blocking passport slot + 3 card slots + boarding pass slip", "Includes luxury magnetic gift box", "Specify initials during checkout note"],
    variants: {
      colors: ["Caramel Tan", "Forest Spruce", "Midnight Black"],
      sizes: ["Duo Travel Set"]
    },
    inStock: true,
    stockCount: 28,
    delivery: "Fast Qatar-Wide Delivery"
  },
  {
    id: "gift-4",
    name: "Artisanal Pistachio & Saffron Rose Chocolate Chest",
    category: "gifts",
    categoryName: "Gifts",
    price: 175,
    originalPrice: 220,
    rating: 4.9,
    reviewsCount: 104,
    badge: "SWEET LUXURY",
    featured: false,
    trending: true,
    newArrival: false,
    image: "https://images.unsplash.com/photo-1549007994-cb92caebd54b?auto=format&fit=crop&w=800&q=80",
    hoverImage: "https://images.unsplash.com/photo-1582293041079-7814c2f12063?auto=format&fit=crop&w=800&q=80",
    description: "Twenty-four handmade European bonbons featuring Middle Eastern flavor profiles: Roasted Turkish pistachios, Qatari date caramel, saffron ganache, and edible 24k gold leaf flakes.",
    specs: ["24 assorted artisan bonbons (320g)", "Crafted with single-origin Valrhona grand cru cacao", "100% Halal certified ingredients", "Cold-chain thermal packaging included"],
    variants: {
      colors: ["24-Piece Deluxe Chest"],
      sizes: ["Standard"]
    },
    inStock: true,
    stockCount: 45,
    delivery: "Same-Day Delivery in Doha & Lusail"
  },
  {
    id: "gift-5",
    name: "Mother of Pearl Hand-Inlaid Keepsake Chest",
    category: "gifts",
    categoryName: "Gifts",
    price: 320,
    originalPrice: 395,
    rating: 4.9,
    reviewsCount: 47,
    badge: "HANDMADE",
    featured: false,
    trending: false,
    newArrival: true,
    image: "https://images.unsplash.com/photo-1512496015851-a90fb38ba796?auto=format&fit=crop&w=800&q=80",
    hoverImage: "https://images.unsplash.com/photo-1535295972055-1c762f4483e5?auto=format&fit=crop&w=800&q=80",
    description: "An enduring piece of traditional Levantine art. Natural walnut wood individually inlaid with iridescent mother of pearl in geometric Arabesque motifs. Lined with rich plush velvet.",
    specs: ["Solid walnut hardwood frame", "Genuine iridescent coastal mother-of-pearl", "Dimensions: 20cm x 14cm x 8cm", "Includes brass lock and vintage key"],
    variants: {
      colors: ["Natural Walnut & Pearl", "Midnight Stained & Pearl"],
      sizes: ["Medium Chest"]
    },
    inStock: true,
    stockCount: 11,
    delivery: "Fast Qatar-Wide Delivery"
  }
];

// Helper functions for catalog queries
function getAllProducts() {
  return WHOOHU_PRODUCTS;
}

function getProductById(id) {
  return WHOOHU_PRODUCTS.find(p => p.id === id);
}

function getProductsByCategory(category) {
  if (!category || category === "all") return WHOOHU_PRODUCTS;
  return WHOOHU_PRODUCTS.filter(p => p.category.toLowerCase() === category.toLowerCase());
}

function getTrendingProducts() {
  return WHOOHU_PRODUCTS.filter(p => p.trending);
}

function getNewArrivals() {
  return WHOOHU_PRODUCTS.filter(p => p.newArrival);
}

function getFeaturedProducts() {
  return WHOOHU_PRODUCTS.filter(p => p.featured);
}

